
package ListasEnlzadas.implementaciones;

import excepciones.ListException;
import interfaces.IDoubleList;
import java.util.Iterator;

public class DoubleLinkedList<T> implements IDoubleList<T>{

    
private NodoDoble inicio;
private NodoDoble fin;
private int nElementos;

    @Override
    public int lastIndexOf(T o) {
        NodoDoble nodo = fin;
    int index = nElementos - 1;
    while (nodo != null) {
        if (nodo.dato.equals(o)) {
            return index;
        }
        nodo = nodo.ant;
        index--;
    }
    return -1;
    }

    @Override
    public boolean removeLast(T o) {
        NodoDoble nodo = fin;
    while (nodo != null) {
        if (nodo.dato.equals(o)) {
            if (nodo.ant != null) {
                nodo.ant.sig = nodo.sig;
            } else {
                inicio = nodo.sig;
            }

            if (nodo.sig != null) {
                nodo.sig.ant = nodo.ant;
            } else {
                fin = nodo.ant;
            }

            nElementos--;
            return true;
        }
        nodo = nodo.ant;
    }
    return false;
    }


    private class NodoDoble {
    private T dato;
    private NodoDoble ant;
    private NodoDoble sig;

    public NodoDoble(T dato) {
        this.dato = dato;
    }
}

    private class ListIterator implements Iterator<T> {
    private NodoDoble nodoActual;

    public ListIterator(NodoDoble inicio) {
        this.nodoActual = inicio;
    }

    @Override
    public boolean hasNext() {
        return nodoActual != null;
    }

    @Override
    public T next() {
        T dato = nodoActual.dato;
        nodoActual = nodoActual.sig;
        return dato;
        }
    }

    public DoubleLinkedList() {
        inicio = null;
        fin = null;
        nElementos = 0;
    }

    @Override
    public void append(T o) {
        NodoDoble nuevo = new NodoDoble(o);
        if (inicio == null) {
            inicio = nuevo;
        } else {
            fin.sig = nuevo;
            nuevo.ant = fin;
        }
        fin = nuevo;
        nElementos++;
    }

    @Override
    public void insert(T o, int i) throws ListException {
        if (i < 0 || i > nElementos) throw new ListException("Índice fuera de límites");
        NodoDoble nuevo = new NodoDoble(o);
        if (i == 0) {
            if (inicio == null) {
                fin = nuevo;
            } else {
                nuevo.sig = inicio;
                inicio.ant = nuevo;
            }
            inicio = nuevo;
        } else {
            NodoDoble nodo = inicio;
            for (int j = 0; j < i - 1; j++) nodo = nodo.sig;
            nuevo.sig = nodo.sig;
            if (nuevo.sig != null) {
                nuevo.sig.ant = nuevo;
            } else {
                fin = nuevo;
            }
            nuevo.ant = nodo;
            nodo.sig = nuevo;
        }
        nElementos++;
    }

    @Override
    public T get(int i) throws ListException {
        if (empty()) throw new ListException("Lista vacía");
        if (i < 0 || i >= nElementos) throw new ListException("Índice fuera de límites");
        NodoDoble nodo = inicio;
        for (int j = 0; j < i; j++) nodo = nodo.sig;
        return nodo.dato;
    }

    
    public void set(int index, T o) throws ListException {
        if (index < 0 || index >= nElementos) throw new ListException("Índice fuera de límites");
        NodoDoble nodo = inicio;
        for (int j = 0; j < index; j++) nodo = nodo.sig;
        nodo.dato = o;
    }

    @Override
    public T remove(int i) throws ListException {
        if (empty()) throw new ListException("Lista vacía");
        if (i < 0 || i >= nElementos) throw new ListException("Índice fuera de límites");

        T dato;
        if (i == 0) {
            dato = inicio.dato;
            inicio = inicio.sig;
            if (inicio != null) inicio.ant = null;
            else fin = null;
        } else {
            NodoDoble nodo = inicio;
            for (int j = 0; j < i - 1; j++) nodo = nodo.sig;
            dato = nodo.sig.dato;
            nodo.sig = nodo.sig.sig;
            if (nodo.sig != null) nodo.sig.ant = nodo;
            else fin = nodo;
        }
        nElementos--;
        return dato;
    }

    @Override
    public boolean remove(T o) {
        NodoDoble nodo = inicio;
        while (nodo != null) {
            if (nodo.dato.equals(o)) {
                if (nodo.ant != null) nodo.ant.sig = nodo.sig;
                else inicio = nodo.sig;

                if (nodo.sig != null) nodo.sig.ant = nodo.ant;
                else fin = nodo.ant;

                nElementos--;
                return true;
            }
            nodo = nodo.sig;
        }
        return false;
    }

    @Override
    public int indexOf(T o) {
        NodoDoble nodo = inicio;
        int index = 0;
        while (nodo != null) {
            if (nodo.dato.equals(o)) return index;
            nodo = nodo.sig;
            index++;
        }
        return -1;
    }

    @Override
    public void clear() {
        inicio = null;
        fin = null;
        nElementos = 0;
    }

    @Override
    public boolean empty() {
        return inicio == null;
    }

    @Override
    public int size() {
        return nElementos;
    }

  
    public Iterator<T> iterator() {
        return new ListIterator(inicio);
    }

    @Override
    public String toString() {
        StringBuilder s = new StringBuilder("[");
        NodoDoble nodo = inicio;
        while (nodo != null) {
            s.append(nodo.dato);
            if (nodo.sig != null) s.append(", ");
            nodo = nodo.sig;
        }
        s.append("]");
        return s.toString();
    }
}
   

