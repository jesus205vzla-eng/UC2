
package interfaces;


public interface IDoubleList<T> extends Ilist<T>{
    int lastIndexOf(T o);
    
    boolean removeLast(T o);
    
}
